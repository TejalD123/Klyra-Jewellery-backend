const Banner = require("../models/banner.model");
const cloudinary = require("../config/cloudinary.config");
const ApiError = require("../utils/apiError");
const ApiResponse = require("../utils/apiResponse");
const asyncHandler = require("../utils/asyncHandler");

// ---------------------------------------------------------------------
// PUBLIC — GET /api/v1/banners?type=hero
// Returns only active + currently-valid banners, sorted by displayOrder
// ---------------------------------------------------------------------
const getActiveBanners = asyncHandler(async (req, res) => {
  const { type } = req.query;

  const query = { isActive: true };
  if (type) query.type = type;

  const banners = await Banner.find(query).sort({ displayOrder: 1, createdAt: -1 });

  // Filter out expired/not-yet-started banners in JS (keeps query simple)
  const validBanners = banners.filter((b) => b.isCurrentlyValid());

  return res.status(200).json(new ApiResponse(200, validBanners, "Banners fetched successfully."));
});

// ---------------------------------------------------------------------
// ADMIN — GET /api/v1/admin/banners  (all banners, active + inactive)
// ---------------------------------------------------------------------
const getAllBanners = asyncHandler(async (req, res) => {
  const { type } = req.query;
  const query = {};
  if (type) query.type = type;

  const banners = await Banner.find(query).sort({ displayOrder: 1, createdAt: -1 });

  return res.status(200).json(new ApiResponse(200, banners, "All banners fetched successfully."));
});

// ---------------------------------------------------------------------
// ADMIN — POST /api/v1/admin/banners
// multipart/form-data: { type, title, subtitle, ctaText, ctaLink,
//                         backgroundColor, displayOrder, startDate, endDate, image (file) }
// ---------------------------------------------------------------------
const createBanner = asyncHandler(async (req, res) => {
  const {
    type,
    title,
    subtitle,
    ctaText,
    ctaLink,
    backgroundColor,
    displayOrder,
    startDate,
    endDate,
  } = req.body;

  if (type === "hero" && !req.file) {
    throw new ApiError(400, "Image is required for hero banners.");
  }

  const banner = await Banner.create({
    type,
    title,
    subtitle,
    ctaText,
    ctaLink,
    backgroundColor,
    displayOrder: displayOrder || 0,
    startDate: startDate || null,
    endDate: endDate || null,
    image: req.file?.path || undefined,
    imagePublicId: req.file?.filename || undefined,
  });

  return res.status(201).json(new ApiResponse(201, banner, "Banner created successfully."));
});

// ---------------------------------------------------------------------
// ADMIN — PATCH /api/v1/admin/banners/:id
// ---------------------------------------------------------------------
const updateBanner = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const banner = await Banner.findById(id).select("+imagePublicId");
  if (!banner) {
    throw new ApiError(404, "Banner not found.");
  }

  const updatableFields = [
    "title",
    "subtitle",
    "ctaText",
    "ctaLink",
    "backgroundColor",
    "displayOrder",
    "isActive",
    "startDate",
    "endDate",
  ];

  updatableFields.forEach((field) => {
    if (req.body[field] !== undefined) banner[field] = req.body[field];
  });

  // If a new image was uploaded, replace the old one on Cloudinary
  if (req.file) {
    if (banner.imagePublicId) {
      await cloudinary.uploader.destroy(banner.imagePublicId).catch(() => {});
    }
    banner.image = req.file.path;
    banner.imagePublicId = req.file.filename;
  }

  await banner.save();

  return res.status(200).json(new ApiResponse(200, banner, "Banner updated successfully."));
});

// ---------------------------------------------------------------------
// ADMIN — PATCH /api/v1/admin/banners/:id/toggle
// Quick enable/disable without a full edit form
// ---------------------------------------------------------------------
const toggleBannerStatus = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const banner = await Banner.findById(id);
  if (!banner) {
    throw new ApiError(404, "Banner not found.");
  }

  banner.isActive = !banner.isActive;
  await banner.save();

  return res.status(200).json(new ApiResponse(200, banner, `Banner ${banner.isActive ? "activated" : "deactivated"}.`));
});

// ---------------------------------------------------------------------
// ADMIN — DELETE /api/v1/admin/banners/:id
// ---------------------------------------------------------------------
const deleteBanner = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const banner = await Banner.findById(id).select("+imagePublicId");
  if (!banner) {
    throw new ApiError(404, "Banner not found.");
  }

  if (banner.imagePublicId) {
    await cloudinary.uploader.destroy(banner.imagePublicId).catch(() => {});
  }

  await banner.deleteOne();

  return res.status(200).json(new ApiResponse(200, null, "Banner deleted successfully."));
});

module.exports = {
  getActiveBanners,
  getAllBanners,
  createBanner,
  updateBanner,
  toggleBannerStatus,
  deleteBanner,
};