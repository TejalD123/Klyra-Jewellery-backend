const mongoose = require("mongoose");
const Query = require("../models/query.model");
const ApiResponse = require("../utils/apiResponse");
const ApiError = require("../utils/apiError");
const asyncHandler = require("../utils/asyncHandler");
const { notifyAdmins } = require("../services/notification.service");

/**
 * @desc    Submit a new query (contact form) — public, no login required
 * @route   POST /api/queries
 * @access  Public
 */
const createQuery = asyncHandler(async (req, res) => {
  const { name, email, phone, subject, message } = req.body;

  const query = await Query.create({
    name,
    email,
    phone,
    subject,
    message,
    user: req.user?.id || null, // present only if a logged-in user submitted it
  });

  await notifyAdmins({
    type: "new_query",
    title: "New customer query",
    message: `${name} — ${subject || "General enquiry"}`,
    relatedModel: "Query",
    relatedId: query._id,
  });

  return res
    .status(201)
    .json(new ApiResponse(201, query, "Your query has been submitted. We'll get back to you soon."));
});

/**
 * @desc    Get all queries (paginated, filterable by status, searchable)
 * @route   GET /api/queries
 * @access  Admin
 */
const getAllQueries = asyncHandler(async (req, res) => {
  const { status, search, page = 1, limit = 20 } = req.query;

  const filter = {};
  if (status) filter.status = status;
  if (search) filter.$text = { $search: search };

  const pageNum = Math.max(parseInt(page, 10), 1);
  const limitNum = Math.max(parseInt(limit, 10), 1);
  const skip = (pageNum - 1) * limitNum;

  const [queries, total] = await Promise.all([
    Query.find(filter)
      .populate("respondedBy", "username email")
      .sort("-createdAt")
      .skip(skip)
      .limit(limitNum),
    Query.countDocuments(filter),
  ]);

  return res.status(200).json(
    new ApiResponse(200, {
      queries,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum),
      },
    })
  );
});

/**
 * @desc    Get a single query by ID
 * @route   GET /api/queries/:id
 * @access  Admin
 */
const getQueryById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw ApiError.badRequest("Invalid query id");
  }

  const query = await Query.findById(id).populate("respondedBy", "username email");
  if (!query) throw ApiError.notFound("Query not found");

  return res.status(200).json(new ApiResponse(200, query));
});

/**
 * @desc    Respond to a query — sets response text and marks it resolved
 * @route   PATCH /api/queries/:id/respond
 * @access  Admin
 */
const respondToQuery = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { response } = req.body;

  const query = await Query.findById(id);
  if (!query) throw ApiError.notFound("Query not found");

  query.response = response;
  query.status = "resolved";
  query.respondedBy = req.user.id;
  query.respondedAt = new Date();
  await query.save();

  return res.status(200).json(new ApiResponse(200, query, "Response saved"));
});

/**
 * @desc    Update a query's status without necessarily responding (e.g. mark in_progress)
 * @route   PATCH /api/queries/:id/status
 * @access  Admin
 */
const updateQueryStatus = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const query = await Query.findByIdAndUpdate(id, { status }, { new: true });
  if (!query) throw ApiError.notFound("Query not found");

  return res.status(200).json(new ApiResponse(200, query, "Status updated"));
});

/**
 * @desc    Delete a query
 * @route   DELETE /api/queries/:id
 * @access  Admin
 */
const deleteQuery = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw ApiError.badRequest("Invalid query id");
  }

  const query = await Query.findByIdAndDelete(id);
  if (!query) throw ApiError.notFound("Query not found");

  return res.status(200).json(new ApiResponse(200, null, "Query deleted"));
});

module.exports = {
  createQuery,
  getAllQueries,
  getQueryById,
  respondToQuery,
  updateQueryStatus,
  deleteQuery,
};